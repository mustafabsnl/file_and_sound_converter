import tkinter as tk
from pdf2image import convert_from_path
from tkinter import filedialog, messagebox, Button
from pdf2docx import Converter
from docx2pdf import convert 
from PyPDF2 import PdfReader, PdfWriter
from docx import Document  
from PIL import Image
from fpdf import FPDF
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
from moviepy.editor import VideoFileClip, AudioFileClip, ColorClip
import tkinter.messagebox as messagebox
from pydub import AudioSegment
import os
# Word to Pdf Convert
class WordToPdfApp(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.configure(bg='lightgray')

        # Word dosyasını seçme butonu
        self.Word_select_pdf_button = tk.Button(self, text="Select Word File", command=self.select_word)
        self.Word_select_pdf_button.pack(pady=10)

        # Dönüştürme butonu
        self.convert_button = tk.Button(self, text="Convert to Pdf", command=self.convert_word_to_pdf, state=tk.DISABLED)
        self.convert_button.pack(pady=10)

        # Geri dönme butonu
        self.back_button = tk.Button(self, text="Back to Main Page", command=self.go_back)
        self.back_button.pack(pady=10)

        # Dosya yollarını saklamak için değişkenler
        self.word_file_path = None
        self.pdf_file_path = None

    def select_word(self):
        self.word_file_path = filedialog.askopenfilename(filetypes=[("Word files", "*.docx")])
        if self.word_file_path:
            self.convert_button.config(state=tk.NORMAL)

    def convert_word_to_pdf(self):
        if not self.word_file_path:
            messagebox.showerror("Error", "Please select a Word file first.")
            return

        self.pdf_file_path = filedialog.asksaveasfilename(defaultextension=".pdf", filetypes=[("Pdf files", "*.pdf")])
        if not self.pdf_file_path:
            return

        try:
            print(f"Converting {self.word_file_path} to {self.pdf_file_path}")  # Hata ayıklama için
            converter = Converter(self.word_file_path)
            converter.convert(self.pdf_file_path, start=0, end=None)
            converter.close()
            messagebox.showinfo("Success", f"Conversion successful! File saved as {self.pdf_file_path}")
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {e}")

    def go_back(self):
        self.pack_forget()
        self.controller.main_frame.pack(fill=tk.BOTH, expand=True)


# PDF to Word Convert
class PdfToWordApp(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.configure(bg='lightgray')

        # PDF dosyasını seçme butonu
        self.Pdf_select_pdf_button = tk.Button(self, text="Select PDF File", command=self.select_pdf)
        self.Pdf_select_pdf_button.pack(pady=10)

        # Dönüştürme butonu
        self.convert_button = tk.Button(self, text="Convert to DOCX", command=self.convert_pdf_to_word, state=tk.DISABLED)
        self.convert_button.pack(pady=10)

        # Geri dönme butonu
        self.back_button = tk.Button(self, text="Back to Main Page", command=self.go_back)
        self.back_button.pack(pady=10)

        # Dosya yollarını saklamak için değişkenler
        self.pdf_file_path = None
        self.docx_file_path = None

    def select_pdf(self):
        self.pdf_file_path = filedialog.askopenfilename(filetypes=[("PDF files", "*.pdf")])
        if self.pdf_file_path:
            self.convert_button.config(state=tk.NORMAL)

    def convert_pdf_to_word(self):
        if not self.pdf_file_path:
            messagebox.showerror("Error", "Please select a PDF file first.")
            return

        self.word_file_path = filedialog.asksaveasfilename(defaultextension=".docx", filetypes=[("Word files", "*.docx")])
        if not self.word_file_path:
            return

        try:
            converter = Converter(self.pdf_file_path)
            converter.convert(self.word_file_path, start=0, end=None)
            converter.close()
            messagebox.showinfo("Success", f"Conversion successful! File saved as {self.word_file_path}")
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {e}")

    def go_back(self):
        self.pack_forget()
        self.controller.main_frame.pack(fill=tk.BOTH, expand=True)


# pdf to jpg convert
class PdfToJpgApp(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.configure(bg='lightgray')

        # PDF dosyasını seçme butonu
        self.Pdf_select_pdf_button = tk.Button(self, text="Select PDF File", command=self.select_pdf)
        self.Pdf_select_pdf_button.pack(pady=10)

        # Dönüştürme butonu
        self.convert_button = tk.Button(self, text="Convert to Jpg", command=self.convert_pdf_to_jpg, state=tk.DISABLED)
        self.convert_button.pack(pady=10)

        # Geri dönme butonu
        self.back_button = tk.Button(self, text="Back to Main Page", command=self.go_back)
        self.back_button.pack(pady=10)

        # Dosya yollarını saklamak için değişkenler
        self.pdf_file_path = None
        self.jpg_file_path = None

    def select_pdf(self):
        self.pdf_file_path = filedialog.askopenfilename(filetypes=[("PDF files", "*.pdf")])
        if self.pdf_file_path:
            self.convert_button.config(state=tk.NORMAL)

    def convert_pdf_to_jpg(self):
        if not self.pdf_file_path:
            messagebox.showerror("Error", "Please select a PDF file first.")
            return

        # Kullanıcıdan çıktı dosyalarının kaydedileceği klasörü seçmesini isteyin
        output_directory = filedialog.askdirectory()
        if not output_directory:
            return


        try:
             # PDF'yi görüntülere dönüştür
            images = convert_from_path(self.pdf_file_path)

            # Her bir görüntüyü JPG olarak kaydet
            for i, image in enumerate(images):
                jpg_file_path = f"{output_directory}/page_{i + 1}.jpg"
                image.save(jpg_file_path, 'JPEG')

            messagebox.showinfo("Success", f"Conversion successful! Files saved in {output_directory}")
        except Exception as e:
            # Hata ayıklamak için ek bilgi sağlamak
            messagebox.showerror("Error", f"An error occurred: {e}")


    def go_back(self):
        self.pack_forget()
        self.controller.main_frame.pack(fill=tk.BOTH, expand=True)

# jpg to pdf convert
class JpgToPdfApp(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.configure(bg='lightgray')

        # Jpg dosyasını seçme butonu
        self.Jpg_select_jpg_button = tk.Button(self, text="Select Jpg File", command=self.select_jpg)
        self.Jpg_select_jpg_button.pack(pady=10)

        # Dönüştürme butonu
        self.convert_button = tk.Button(self, text="Convert to Pdf", command=self.convert_jpg_to_pdf, state=tk.DISABLED)
        self.convert_button.pack(pady=10)

        # Geri dönme butonu
        self.back_button = tk.Button(self, text="Back to Main Page", command=self.go_back)
        self.back_button.pack(pady=10)

        # Dosya yollarını saklamak için değişkenler
        self.jpg_file_path = None
        self.pdf_file_path = None

    def select_jpg(self):
        self.jpg_file_path = filedialog.askopenfilename(filetypes=[("jpg file", "*.jpg")])
        if self.jpg_file_path:
            self.convert_button.config(state=tk.NORMAL)

    def convert_jpg_to_pdf(self):
        if not self.jpg_file_path:
            messagebox.showerror("Error", "Please select a Jpg file first.")
            return

        self.pdf_file_path = filedialog.asksaveasfilename(defaultextension=".pdf", filetypes=[("Pdf files", "*.pdf")])
        if not self.pdf_file_path:
            return

        try:
            # JPG dosyasını aç
            img = Image.open(self.jpg_file_path)

            # JPG dosyasını PDF olarak kaydet // özünürlük değeri ayarı
            img.save(self.pdf_file_path, "PDF", resolution=100.0)

            messagebox.showinfo("Success", f"Conversion successful! Files saved in {self.pdf_file_path}")
        except Exception as e:
            # Hata ayıklamak için ek bilgi sağlamak
            messagebox.showerror("Error", f"An error occurred: {e}")

    def go_back(self):
        self.pack_forget()
        self.controller.main_frame.pack(fill=tk.BOTH, expand=True)

# Marge Word
class MargeWord(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.configure(bg='lightgray')
    
        # Word dosyalarını seçme butonu
        self.Marge_select_word_button = tk.Button(self, text="Select Word Files", command=self.select_word_files)
        self.Marge_select_word_button.pack(pady=10)

        # Birleştirme butonu
        self.convert_button = tk.Button(self, text="Merge Word Files", command=self.merge_word_files, state=tk.DISABLED)
        self.convert_button.pack(pady=10)

        # Geri dönme butonu
        self.back_button = tk.Button(self, text="Back to Main Page", command=self.go_back)
        self.back_button.pack(pady=10)

        # Dosya yollarını saklamak için değişkenler
        self.word_file_paths = []

    def select_word_files(self):
        self.word_file_paths = filedialog.askopenfilenames(filetypes=[("Word files", "*.docx")])
        if self.word_file_paths:
            self.convert_button.config(state=tk.NORMAL)

    def merge_word_files(self):
        if not self.word_file_paths:
            messagebox.showerror("Error", "Please select Word files first.")
            return

        output_file_path = filedialog.asksaveasfilename(defaultextension=".docx", filetypes=[("Word files", "*.docx")])
        if not output_file_path:
            return

        try:
            merged_doc = Document()
            for i, file_path in enumerate(self.word_file_paths):
                doc = Document(file_path)
                for para in doc.paragraphs:
                    merged_doc.add_paragraph(para.text)
                # Eğer tabloları da eklemek isterseniz:
                for table in doc.tables:
                    new_table = merged_doc.add_table(rows=0, cols=len(table.columns))
                    for row in table.rows:
                        new_row = new_table.add_row()
                        for j, cell in enumerate(row.cells):
                            new_row.cells[j].text = cell.text
                # Sayfa sonu ekle
                if i < len(self.word_file_paths) - 1:
                    merged_doc.add_page_break()
            merged_doc.save(output_file_path)
            messagebox.showinfo("Success", f"Word files merged successfully! File saved as {output_file_path}")
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {e}")

    def go_back(self):
        self.pack_forget()
        self.controller.main_frame.pack(fill=tk.BOTH, expand=True)

# Merge PDF
class MargePdf(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.configure(bg='lightgray')

        # PDF dosyalarını seçme butonu
        self.Marge_select_pdf_button = tk.Button(self, text="Select PDF Files", command=self.select_pdfs)
        self.Marge_select_pdf_button.pack(pady=10)

        # Birleştirme butonu
        self.merge_button = tk.Button(self, text="Merge PDFs", command=self.merge_pdfs, state=tk.DISABLED)
        self.merge_button.pack(pady=10)

        # Geri dönme butonu
        self.back_button = tk.Button(self, text="Back to Main Page", command=self.go_back)
        self.back_button.pack(pady=10)

        # Dosya yollarını saklamak için değişkenler
        self.pdf_file_paths = []

    def select_pdfs(self):
        self.pdf_file_paths = filedialog.askopenfilenames(
            filetypes=[("PDF files", "*.pdf")],
            title="Select PDF Files"
        )
        if self.pdf_file_paths:
            self.merge_button.config(state=tk.NORMAL)

    def merge_pdfs(self):
        if not self.pdf_file_paths:  
            messagebox.showerror("Error", "Please select PDF files first.")
            return

        output_file_path = filedialog.asksaveasfilename(
            defaultextension=".pdf",  # Çıktı PDF dosyası olacak
            filetypes=[("PDF files", "*.pdf")],
            title="Save Merged PDF"
        )
        if not output_file_path:
            return

        try:
            pdf_writer = PdfWriter()
            for pdf_file_path in self.pdf_file_paths:
                pdf_reader = PdfReader(pdf_file_path)
                for page_num in range(len(pdf_reader.pages)):
                    pdf_writer.add_page(pdf_reader.pages[page_num])

            with open(output_file_path, "wb") as output_file:
                pdf_writer.write(output_file)

            messagebox.showinfo("Success", f"PDFs merged successfully! File saved as {output_file_path}")
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {e}")

    def go_back(self):
        self.pack_forget()
        self.controller.main_frame.pack(fill=tk.BOTH, expand=True)
class index:
    def __init__(self, root):
        self.root = root
        self.root.title("Main Page")
        
        self.main_frame = tk.Frame(self.root)
        self.main_frame.pack(fill=tk.BOTH, expand=True)

        self.page7_button = tk.Button(self.main_frame, text="Go to File Converter", command=self.file_converter)
        self.page7_button.pack(pady=10)

        self.page8_button = tk.Button(self.main_frame, text="Go to sound Converter", command=self.sound_converter)
        self.page8_button.pack(pady=10)

    def file_converter(self):
        self.main_frame.pack_forget() # Mevcut sayfayı gizle
        MainApp(self.root)  # MainApp sınıfını başlat    
    def sound_converter(self):
        self.main_frame.pack_forget() # Mevcut sayfayı gizle
        SoundConverter(self.root)  # Mp4ToMp3 sınıfını başlat



class Mp4ToWav(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.configure(bg='lightgray')
        
        # mp4 dosyasını seçme butonu
        self.mp4_select_button = tk.Button(self, text="Select mp4 File", command=self.select_mp4)
        self.mp4_select_button.pack(pady=10)
        
        # Dönüştürme butonu
        self.convert_button = tk.Button(self, text="Convert to Wav", command=self.mp4_to_wav_converter, state=tk.DISABLED)
        self.convert_button.pack(pady=10)
        
        # Geri dönme butonu
        self.back_button = tk.Button(self, text="Back to Main Page", command=self.go_back)
        self.back_button.pack(pady=10)

        # Dosya yollarını saklamak için değişkenler
        self.mp4_file_path = None
        self.wav_file_path = None

    def select_mp4(self):
        self.mp4_file_path = filedialog.askopenfilename(filetypes=[("MP4 files", "*.mp4")])
        if self.mp4_file_path:
            self.convert_button.config(state=tk.NORMAL)

    def mp4_to_wav_converter(self):
        if not self.mp4_file_path:
            messagebox.showerror("Error", "Please select an MP4 file first.")
            return

        self.wav_file_path = filedialog.asksaveasfilename(defaultextension=".wav", filetypes=[("Wav files", "*.wav")])
        if not self.wav_file_path:
            return
        
        try:
            # MP4 dosyasını aç
            video = VideoFileClip(self.mp4_file_path)

            # Wav dosyasını kaydet
            audio = video.audio
            audio.write_audiofile(self.wav_file_path)

            messagebox.showinfo("Success", f"Conversion successful! File saved in {self.wav_file_path}")
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {e}")
    def go_back(self):
        self.pack_forget()
        self.controller.main_frame.pack(fill=tk.BOTH, expand=True)


class WavToMp4(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.configure(bg='lightgray')
        
        # wav dosyasını seçme butonu
        self.wav_select_button = tk.Button(self, text="Select wav File", command=self.select_wav)
        self.wav_select_button.pack(pady=10)
        
        # Dönüştürme butonu
        self.convert_button = tk.Button(self, text="Convert to mp4", command=self.wav_to_mp4_converter, state=tk.DISABLED)
        self.convert_button.pack(pady=10)
        
        # Geri dönme butonu
        self.back_button = tk.Button(self, text="Back to Main Page", command=self.go_back)
        self.back_button.pack(pady=10)

        # Dosya yollarını saklamak için değişkenler
        self.wav_file_path = None
        self.mp3_file_path = None

    def select_wav(self):
        self.wav_file_path = filedialog.askopenfilename(filetypes=[("wav files", "*.wav")])
        if self.wav_file_path:
            self.convert_button.config(state=tk.NORMAL)

    def wav_to_mp4_converter(self):
        if not self.wav_file_path:
            messagebox.showerror("Error", "Please select an wav file first.")
            return

        self.mp4_file_path = filedialog.asksaveasfilename(defaultextension=".mp4", filetypes=[("mp4 files", "*.mp4")])
        if not self.mp4_file_path:
            return
        
        try:
            # WAV dosyasını yükle
            audio_clip = AudioFileClip(self.wav_file_path)
            
            # Boş bir video klip oluştur
            video_clip = ColorClip(size=(640, 480), color=(0, 0, 0), duration=audio_clip.duration)
            video_clip = video_clip.set_audio(audio_clip)

            # MP4 dosyasını kaydet, fps burada belirtilmelidir
            video_clip.write_videofile(self.mp4_file_path, codec='libx264', audio_codec='aac', fps=24)

            messagebox.showinfo("Success", f"Conversion successful! File saved in {self.mp4_file_path}")
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {e}")

    def go_back(self):
        self.pack_forget()
        self.controller.main_frame.pack(fill=tk.BOTH, expand=True)

class Mp3ToWav(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.configure(bg='lightgray')
        
        # mp3 dosyasını seçme butonu
        self.mp3_select_button = tk.Button(self, text="Select mp3 File", command=self.select_mp3)
        self.mp3_select_button.pack(pady=10)
        
        # Dönüştürme butonu
        self.convert_button = tk.Button(self, text="Convert to Wav", command=self.mp3_to_wav_converter, state=tk.DISABLED)
        self.convert_button.pack(pady=10)
        
        # Geri dönme butonu
        self.back_button = tk.Button(self, text="Back to Main Page", command=self.go_back)
        self.back_button.pack(pady=10)

        # Dosya yollarını saklamak için değişkenler
        self.mp3_file_path = None
        self.wav_file_path = None

    def select_mp3(self):
        self.mp3_file_path = filedialog.askopenfilename(filetypes=[("MP3 files", "*.mp3")])
        if self.mp3_file_path:
            self.convert_button.config(state=tk.NORMAL)

    def mp3_to_wav_converter(self):
        if not self.mp3_file_path:
            messagebox.showerror("Error", "Please select an MP4 file first.")
            return

        self.wav_file_path = filedialog.asksaveasfilename(defaultextension=".wav", filetypes=[("Wav files", "*.wav")])
        if not self.wav_file_path:
            return
        
        try:
            # MP3 dosyasını aç
            video = VideoFileClip(self.mp3_file_path)

            # Wav dosyasını kaydet
            audio = video.audio
            audio.write_audiofile(self.wav_file_path)

            messagebox.showinfo("Success", f"Conversion successful! File saved in {self.wav_file_path}")
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {e}")
    def go_back(self):
        self.pack_forget()
        self.controller.main_frame.pack(fill=tk.BOTH, expand=True)


class WavToMp3(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.configure(bg='lightgray')
        
        # wav dosyasını seçme butonu
        self.wav_select_button = tk.Button(self, text="Select wav File", command=self.select_wav)
        self.wav_select_button.pack(pady=10)
        
        # Dönüştürme butonu
        self.convert_button = tk.Button(self, text="Convert to Mp3", command=self.wav_to_mp3_converter, state=tk.DISABLED)
        self.convert_button.pack(pady=10)
        
        # Geri dönme butonu
        self.back_button = tk.Button(self, text="Back to Main Page", command=self.go_back)
        self.back_button.pack(pady=10)

        # Dosya yollarını saklamak için değişkenler
        self.wav_file_path = None
        self.mp3_file_path = None

    def select_wav(self):
        self.wav_file_path = filedialog.askopenfilename(filetypes=[("Wav files", "*.wav")])
        if self.wav_file_path:
            self.convert_button.config(state=tk.NORMAL)

    def wav_to_mp3_converter(self):
        if not self.wav_file_path:
            messagebox.showerror("Error", "Please select an wav file first.")
            return

        self.mp3_file_path = filedialog.asksaveasfilename(defaultextension=".mp3", filetypes=[("Mp3 files", "*.mp3")])
        if not self.mp3_file_path:
            return
        
        try:
            # WAV dosyasını yükle
            audio = AudioSegment.from_wav(self.wav_file_path)
            
            # MP3 dosyasını kaydet
            audio.export(self.mp3_file_path, format="mp3")

            messagebox.showinfo("Success", f"Conversion successful! File saved in {self.mp3_file_path}")
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {e}")
    def go_back(self):
        self.pack_forget()
        self.controller.main_frame.pack(fill=tk.BOTH, expand=True)



class Mp3ToAac(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.configure(bg='lightgray')
        
        # MP3 dosyasını seçme butonu
        self.mp3_select_button = tk.Button(self, text="Select MP3 File", command=self.select_mp3)
        self.mp3_select_button.pack(pady=10)
        
        # Dönüştürme butonu
        self.convert_button = tk.Button(self, text="Convert to AAC", command=self.mp3_to_aac_converter, state=tk.DISABLED)
        self.convert_button.pack(pady=10)
        
        # Geri dönme butonu
        self.back_button = tk.Button(self, text="Back to Main Page", command=self.go_back)
        self.back_button.pack(pady=10)

        # Dosya yollarını saklamak için değişkenler
        self.mp3_file_path = None
        self.aac_file_path = None

    def select_mp3(self):
        self.mp3_file_path = filedialog.askopenfilename(filetypes=[("MP3 files", "*.mp3")])
        if self.mp3_file_path:
            self.convert_button.config(state=tk.NORMAL)

    def mp3_to_aac_converter(self):
        if not self.mp3_file_path:
            messagebox.showerror("Error", "Please select an MP3 file first.")
            return

        self.aac_file_path = filedialog.asksaveasfilename(defaultextension=".aac", filetypes=[("AAC files", "*.aac")])
        if not self.aac_file_path:
            return
        
        try:
            # MP3 dosyasını aç
            audio = AudioSegment.from_file(self.mp3_file_path, format="mp3")

            # AAC dosyasını kaydet
            audio.export(self.aac_file_path, format="aac")

            messagebox.showinfo("Success", f"Conversion successful! File saved in {self.aac_file_path}")
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {e}")

    def go_back(self):
        self.pack_forget()
        self.controller.main_frame.pack(fill=tk.BOTH, expand=True)


class AacToMp3(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.configure(bg='lightgray')
        
        # aac dosyasını seçme butonu
        self.aac_select_button = tk.Button(self, text="Select aac File", command=self.select_aac)
        self.aac_select_button.pack(pady=10)
        
        # Dönüştürme butonu
        self.convert_button = tk.Button(self, text="Convert to Mp3", command=self.aac_to_mp3_converter, state=tk.DISABLED)
        self.convert_button.pack(pady=10)
        
        # Geri dönme butonu
        self.back_button = tk.Button(self, text="Back to Main Page", command=self.go_back)
        self.back_button.pack(pady=10)

        # Dosya yollarını saklamak için değişkenler
        self.aac_file_path = None
        self.mp3_file_path = None

    def select_aac(self):
        self.aac_file_path = filedialog.askopenfilename(filetypes=[("aac files", "*.aac")])
        if self.aac_file_path:
            self.convert_button.config(state=tk.NORMAL)

    def aac_to_mp3_converter(self):
        if not self.aac_file_path:
            messagebox.showerror("Error", "Please select an aac file first.")
            return

        self.mp3_file_path = filedialog.asksaveasfilename(defaultextension=".mp3", filetypes=[("mp3 files", "*.mp3")])
        if not self.mp3_file_path:
            return
        
        try:
            # aac dosyasını aç
            audio = AudioSegment.from_file(self.aac_file_path, format="aac")

            # mp3 dosyasını kaydet
            audio.export(self.mp3_file_path, format="mp3")

            messagebox.showinfo("Success", f"Conversion successful! File saved in {self.mp3_file_path}")
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {e}")

    def go_back(self):
        self.pack_forget()
        self.controller.main_frame.pack(fill=tk.BOTH, expand=True)


class AacToWav(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.configure(bg='lightgray')
        
        # aac dosyasını seçme butonu
        self.aac_select_button = tk.Button(self, text="Select aac File", command=self.select_aac)
        self.aac_select_button.pack(pady=10)
        
        # Dönüştürme butonu
        self.convert_button = tk.Button(self, text="Convert to Wav", command=self.aac_to_wav_converter, state=tk.DISABLED)
        self.convert_button.pack(pady=10)
        
        # Geri dönme butonu
        self.back_button = tk.Button(self, text="Back to Main Page", command=self.go_back)
        self.back_button.pack(pady=10)

        # Dosya yollarını saklamak için değişkenler
        self.aac_file_path = None
        self.wav_file_path = None

    def select_aac(self):
        self.aac_file_path = filedialog.askopenfilename(filetypes=[("aac files", "*.aac")])
        if self.aac_file_path:
            self.convert_button.config(state=tk.NORMAL)

    def aac_to_wav_converter(self):
        if not self.aac_file_path:
            messagebox.showerror("Error", "Please select an aac file first.")
            return

        self.wav_file_path = filedialog.asksaveasfilename(defaultextension=".wav", filetypes=[("wav files", "*.wav")])
        if not self.wav_file_path:
            return
        
        try:
            # aac dosyasını aç
            audio = AudioSegment.from_file(self.aac_file_path, format="aac")

            # wav dosyasını kaydet
            audio.export(self.wav_file_path, format="wav")

            messagebox.showinfo("Success", f"Conversion successful! File saved in {self.wav_file_path}")
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {e}")

    def go_back(self):
        self.pack_forget()
        self.controller.main_frame.pack(fill=tk.BOTH, expand=True)


class WavToAac(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.configure(bg='lightgray')
        
        # wav dosyasını seçme butonu
        self.wav_file_path_select_button = tk.Button(self, text="Select wav File", command=self.select_wav)
        self.wav_file_path_select_button.pack(pady=10)
        
        # Dönüştürme butonu
        self.convert_button = tk.Button(self, text="Convert to aac", command=self.wav_to_aac_converter, state=tk.DISABLED)
        self.convert_button.pack(pady=10)
        
        # Geri dönme butonu
        self.back_button = tk.Button(self, text="Back to Main Page", command=self.go_back)
        self.back_button.pack(pady=10)

        # Dosya yollarını saklamak için değişkenler
        self.wav_file_path = None
        self.aac_file_path = None

    def select_wav(self):
        self.wav_file_path = filedialog.askopenfilename(filetypes=[("wav files", "*.wav")])
        if self.wav_file_path:
            self.convert_button.config(state=tk.NORMAL)

    def wav_to_aac_converter(self):
        if not self.wav_file_path:
            messagebox.showerror("Error", "Please select an wav file first.")
            return

        self.aac_file_path = filedialog.asksaveasfilename(defaultextension=".aac", filetypes=[("aac files", "*.aac")])
        if not self.aac_file_path:
            return
        
        try:
            # WAV dosyasını aç
            audio = AudioSegment.from_file(self.wav_file_path, format="wav")

            # AAC dosyasını kaydet
            audio.export(self.aac_file_path, format="aac")

            messagebox.showinfo("Success", f"Conversion successful! File saved in {self.aac_file_path}")
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {e}")


    def go_back(self):
        self.pack_forget()
        self.controller.main_frame.pack(fill=tk.BOTH, expand=True)



class Mp4ToMp3  (tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.configure(bg='lightgray')
        
        # mp4 dosyasını seçme butonu
        self.mp4_select_button = tk.Button(self, text="Select mp4 File", command=self.select_mp4)
        self.mp4_select_button.pack(pady=10)
        
        # Dönüştürme butonu
        self.convert_button = tk.Button(self, text="Convert to mp3", command=self.mp4_to_mp3_converter, state=tk.DISABLED)
        self.convert_button.pack(pady=10)
        
        # Geri dönme butonu
        self.back_button = tk.Button(self, text="Back to Main Page", command=self.go_back)
        self.back_button.pack(pady=10)

        # Dosya yollarını saklamak için değişkenler
        self.mp4_file_path = None
        self.mp3_file_path = None

    def select_mp4(self):
        self.mp4_file_path = filedialog.askopenfilename(filetypes=[("MP4 files", "*.mp4")])
        if self.mp4_file_path:
            self.convert_button.config(state=tk.NORMAL)

    def mp4_to_mp3_converter(self):
        if not self.mp4_file_path:
            messagebox.showerror("Error", "Please select an MP4 file first.")
            return

        self.mp3_file_path = filedialog.asksaveasfilename(defaultextension=".mp3", filetypes=[("MP3 files", "*.mp3")])
        if not self.mp3_file_path:
            return
        
        try:
            # MP4 dosyasını aç
            video = VideoFileClip(self.mp4_file_path)

            # MP3 dosyasını kaydet
            audio = video.audio
            audio.write_audiofile(self.mp3_file_path)

            messagebox.showinfo("Success", f"Conversion successful! File saved in {self.mp3_file_path}")
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {e}")
    def go_back(self):
        self.pack_forget()
        self.controller.main_frame.pack(fill=tk.BOTH, expand=True)

class SoundConverter:
    def __init__(self, root):
        self.root = root
        self.root.title("sound decorder Page")

        self.main_frame = tk.Frame(self.root)
        self.main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Butonlar ekleme
        self.page9_button = tk.Button(self.main_frame, text="Go to Mp4 to Mp3 Converter", command=self.mp4_to_mp3)
        self.page9_button.pack(pady=10)
        
        self.page10_button = tk.Button(self.main_frame, text="Go to Mp4 to Wav Converter", command=self.mp4_to_wav)
        self.page10_button.pack(pady=10)

        self.page11_button = tk.Button(self.main_frame, text="Go to Mp3 to Wav Converter", command=self.mp3_to_wav)
        self.page11_button.pack(pady=10)

        self.page12_button = tk.Button(self.main_frame, text="Go to Mp3 to Aac Converter", command=self.mp3_to_aac)
        self.page12_button.pack(pady=10)

        self.page13_button = tk.Button(self.main_frame, text="Go to Wav to Mp3 Converter", command=self.wav_to_mp3)
        self.page13_button.pack(pady=10)

        self.page14_button = tk.Button(self.main_frame, text="Go to Aac to Mp3 Converter", command=self.aac_to_mp3)
        self.page14_button.pack(pady=10)
        
        self.page15_button = tk.Button(self.main_frame, text="Go to Wav to Mp4 Converter", command=self.wav_to_mp4)
        self.page15_button.pack(pady=10)

        self.page16_button = tk.Button(self.main_frame, text="Go to Aac to Wav Converter", command=self.aac_to_wav)
        self.page16_button.pack(pady=10)

        self.page17_button = tk.Button(self.main_frame, text="Go to Wav to Aac Converter", command=self.wav_to_aac)
        self.page17_button.pack(pady=10)

        self.page18_button = tk.Button(self.main_frame, text="Go to main page ", command=self.show_home_page)
        self.page18_button.pack(pady=10)


        # Sayfaları başlatma
        self.mp4_to_mp3_page = Mp4ToMp3(self.root, self)
        self.mp4_to_wav_page = Mp4ToWav(self.root, self)
        self.wav_to_mp4_page = WavToMp4(self.root, self)
        self.mp3_to_wav_page = Mp3ToWav(self.root, self)
        self.wav_to_mp3_page = WavToMp3(self.root, self)
        self.mp3_to_aac_page = Mp3ToAac(self.root, self)
        self.aac_to_mp3_page = AacToMp3(self.root, self)
        self.aac_to_wav_page = AacToWav(self.root, self)
        self.wav_to_aac_page = WavToAac(self.root, self)

        self.mp4_to_mp3_page.pack_forget()  # Sayfayı başlangıçta gizle
        self.mp4_to_wav_page.pack_forget()  # Sayfayı başlangıçta gizle
        self.wav_to_mp4_page.pack_forget()  # Sayfayı başlangıçta gizle
        self.mp3_to_wav_page.pack_forget()  # Sayfayı başlangıçta gizle
        self.wav_to_mp3_page.pack_forget()  # Sayfayı başlangıçta gizle
        self.mp3_to_aac_page.pack_forget()  # Sayfayı başlangıçta gizle
        self.aac_to_mp3_page.pack_forget()  # Sayfayı başlangıçta gizle
        self.aac_to_wav_page.pack_forget()  # Sayfayı başlangıçta gizle
        self.wav_to_aac_page.pack_forget()  # Sayfayı başlangıçta gizle

    def show_home_page(self):
        self.main_frame.pack_forget()
        index(self.root)  # Index sınıfını başlat

    def mp4_to_mp3(self):
        self.main_frame.pack_forget()
        self.mp4_to_mp3_page.pack(fill=tk.BOTH, expand=True)

    def mp4_to_wav(self):
        self.main_frame.pack_forget()
        self.mp4_to_wav_page.pack(fill=tk.BOTH, expand=True)

    def wav_to_mp4(self):
        self.main_frame.pack_forget()
        self.wav_to_mp4_page.pack(fill=tk.BOTH, expand=True)

    def mp3_to_wav(self):
        self.main_frame.pack_forget()
        self.mp3_to_wav_page.pack(fill=tk.BOTH, expand=True)
        
    def wav_to_mp3(self):
        self.main_frame.pack_forget()
        self.wav_to_mp3_page.pack(fill=tk.BOTH, expand=True)

    def mp3_to_aac(self):
        self.main_frame.pack_forget()
        self.mp3_to_aac_page.pack(fill=tk.BOTH, expand=True)

    def aac_to_mp3(self):
        self.main_frame.pack_forget()
        self.aac_to_mp3_page.pack(fill=tk.BOTH, expand=True)

    def aac_to_wav(self):
        self.main_frame.pack_forget()
        self.aac_to_wav_page.pack(fill=tk.BOTH, expand=True)

    def wav_to_aac(self):
        self.main_frame.pack_forget()
        self.wav_to_aac_page.pack(fill=tk.BOTH, expand=True)



# Pydub ve ffmpeg modüllerini kontrol 
try:
    from pydub import AudioSegment
    print("pydub ve ffmpeg modülleri yüklü ve kullanılabilir.")
except ImportError:
    print("pydub veya ffmpeg modülü yüklü değil. Lütfen yükleyin.")


class MainApp:
    def __init__(self, root):
        self.root = root
        self.root.title("file decorder Page")

        self.main_frame = tk.Frame(self.root)
        self.main_frame.pack(fill=tk.BOTH, expand=True)

        # Butonlar ekleme
        self.page1_button = tk.Button(self.main_frame, text="Go to PDF to Word Converter", command=self.show_pdf_to_word)
        self.page1_button.pack(pady=10)

        self.page2_button = tk.Button(self.main_frame, text="Go to Merge PDF", command=self.show_merge_pdf)
        self.page2_button.pack(pady=10)

        self.page3_button = tk.Button(self.main_frame, text="Go to Merge Word", command=self.show_merge_word)
        self.page3_button.pack(pady=10)

        self.page4_button = tk.Button(self.main_frame, text="Go to PDF to Jpg Converter", command=self.show_pdf_to_jpg)
        self.page4_button.pack(pady=10)

        self.page5_button = tk.Button(self.main_frame, text="Go to Jpg to Pdf Converter", command=self.show_jpg_to_pdf)
        self.page5_button.pack(pady=10)

        self.page6_button = tk.Button(self.main_frame, text="Go to Word to Pdf Converter", command=self.show_word_to_pdf)
        self.page6_button.pack(pady=10)

        self.page19_button = tk.Button(self.main_frame, text="Go to main page ", command=self.show_home_page)
        self.page19_button.pack(pady=10)


        # Sayfaları başlatma
        self.pdf_to_word_page = PdfToWordApp(self.root, self)
        self.word_to_pdf_page = WordToPdfApp(self.root, self)
        self.pdf_to_jpg_page = PdfToJpgApp(self.root, self)
        self.jpg_to_pdf_page = JpgToPdfApp(self.root, self)
        self.merge_pdf_page = MargePdf(self.root, self)
        self.merge_word_page = MargeWord(self.root, self)

        self.word_to_pdf_page.pack_forget()  # Sayfayı başlangıçta gizle
        self.jpg_to_pdf_page.pack_forget()  # Sayfayı başlangıçta gizle
        self.pdf_to_jpg_page.pack_forget()  # Sayfayı başlangıçta gizle
        self.pdf_to_word_page.pack_forget()  # Sayfayı başlangıçta gizle
        self.merge_pdf_page.pack_forget()  # Sayfayı başlangıçta gizle
        self.merge_word_page.pack_forget()  # Sayfayı başlangıçta gizle

    
    def show_home_page(self):
        self.main_frame.pack_forget()
        index(self.root)  # index sınıfını başlat

    def show_pdf_to_word(self):
        self.main_frame.pack_forget()
        self.pdf_to_word_page.pack(fill=tk.BOTH, expand=True)

    def show_word_to_pdf(self):
        self.main_frame.pack_forget()
        self.word_to_pdf_page.pack(fill=tk.BOTH, expand=True)

    def show_pdf_to_jpg(self):
        self.main_frame.pack_forget()
        self.pdf_to_jpg_page.pack(fill=tk.BOTH, expand=True)

    def show_jpg_to_pdf(self):
        self.main_frame.pack_forget()
        self.jpg_to_pdf_page.pack(fill=tk.BOTH, expand=True)

    def show_merge_pdf(self):
        self.main_frame.pack_forget()
        self.merge_pdf_page.pack(fill=tk.BOTH, expand=True)
        
    def show_merge_word(self):
        self.main_frame.pack_forget()
        self.merge_word_page.pack(fill=tk.BOTH, expand=True)

if __name__ == "__main__":
    root = tk.Tk()
    app = index(root)
    root.mainloop()
